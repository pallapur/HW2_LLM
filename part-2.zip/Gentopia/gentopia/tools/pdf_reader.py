from typing import AnyStr, Any, Optional, Type
import io
import requests
import PyPDF2
from pydantic import BaseModel, Field
from gentopia.tools.basetool import BaseTool

class PDFReaderArgs(BaseModel):
    url: str = Field(..., description="URL of the PDF file to read")

class PDFReader(BaseTool):
    """Tool that adds the capability to read a PDF file from a given URL."""
    name = "pdf_reader"
    description = ("A tool for reading PDF files from a given URL. "
                   "Input should be a URL pointing to a PDF file.")
    args_schema: Optional[Type[BaseModel]] = PDFReaderArgs

    def _run(self, url: AnyStr) -> str:
        try:
            # Download the PDF file
            response = requests.get(url)
            response.raise_for_status()  # Raise an exception for bad status codes

            # Create a PDF reader object
            pdf_file = io.BytesIO(response.content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)

            # Extract text from all pages
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n\n"

            return text.strip()
        except requests.RequestException as e:
            return f"Error downloading the PDF: {str(e)}"
        except PyPDF2.errors.PdfReadError as e:
            return f"Error reading the PDF: {str(e)}"
        except Exception as e:
            return f"An unexpected error occurred: {str(e)}"

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError

if __name__ == "__main__":
    pdf_reader = PDFReader()
    ans = pdf_reader._run("https://example.com/sample.pdf")
    print(ans)